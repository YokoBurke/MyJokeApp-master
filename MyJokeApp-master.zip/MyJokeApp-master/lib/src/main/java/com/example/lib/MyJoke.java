package com.example.lib;

public class MyJoke {
    public String getJoke() {
        return "This is totally a funny joke";
    }
}
